# M3U Player 2.3 (Kotlin + Media3 ExoPlayer)

- Small player on top, tap the fullscreen button to go fullscreen (never automatic)
- Bottom tabs: Home, Live TV (categories), Favorites, History, Playlists, Settings
- Playlists: add M3U file or link, many playlists, refresh, delete
- Background audio (foreground media service + notification controls)
- Sound fixes: FFmpeg software audio decoder, audio-track picker, volume boost
- Quality picker, subtitles, aspect ratio, sleep timer, Picture-in-Picture
- Settings: language (System/English/বাংলা), Dark/Light theme, buffer, max quality, reconnect, skip broken channels, user-agent ...
- Auto sound repair: if a channel has an audio decoder error the player switches to the FFmpeg decoder by itself
- Audio language preference, audio-focus switch, reset settings

Build: push this folder (or M3UPlayer.zip) to GitHub, the Actions workflow builds the APK.
The APK is signed with a fixed key (app/debug.keystore) so new builds install over old ones.

## What is new in 2.3
- Settings: modern card design, every option has an icon; new options: Text size, Show channel logos, Hide player controls after, Video quality (360p … 2K), Live TV only working channels, Check Live TV again, Add playlist (+)
- Player: the "Auto" chip and the ♪ audio chip are gone; the ⋮ button opens an icon dropdown with Quality (360p, 480p, 720p, 1080p, 2K), Audio track, Subtitles, Aspect ratio, Sleep timer, Picture-in-Picture, Settings
- The "Now playing" box under the video is removed
- Live TV tab: tests every link (16 at a time) and lists only the channels that work (result is remembered for 6 hours, tap the bar to check again)
- Playlists tab: "Saved files (N)" screen with back arrow, + button (upload file or add m3u8 link, many files at once), rows with channel count, edit (rename / change link) and delete
