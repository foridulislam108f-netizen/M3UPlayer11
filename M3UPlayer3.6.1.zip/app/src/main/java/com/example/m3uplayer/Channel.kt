package com.example.m3uplayer

data class Channel(
    val name: String,
    val url: String,
    val logo: String,
    val group: String
)

data class PlaylistInfo(
    val id: String,
    val name: String,
    val source: String,   // original URL, or "" for a file that was imported
    val isUrl: Boolean,
    val count: Int = 0,   // number of channels
    val updatedAt: Long = 0L  // last successful load/refresh time (epoch ms)
)
