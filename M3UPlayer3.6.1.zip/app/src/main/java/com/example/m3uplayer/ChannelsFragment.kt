package com.example.m3uplayer

import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.os.bundleOf
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.m3uplayer.databinding.FragmentChannelsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

/** Home (all channels), Live TV (only working links), Favorites and History share this screen. */
class ChannelsFragment : Fragment(R.layout.fragment_channels) {

    private var _b: FragmentChannelsBinding? = null
    private val b get() = _b!!

    private val mode: Int get() = requireArguments().getInt("mode")
    private var query = ""
    private var grid = false
    private var shown: List<ChannelItem> = emptyList()
    private lateinit var adapter: ChannelAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _b = FragmentChannelsBinding.bind(view)

        adapter = ChannelAdapter(onClick = ::play, onFav = { Store.toggleFav(it.url) })
        grid = Prefs.sp.getBoolean("grid_$mode", false)  // single list; compact rows show ~6 on screen
        applyLayoutMode()

        b.btnGrid.setOnClickListener {
            grid = !grid
            Prefs.sp.edit().putBoolean("grid_$mode", grid).apply()
            applyLayoutMode()
        }
        b.btnSearch.setOnClickListener {
            val show = b.search.visibility != View.VISIBLE
            b.search.visibility = if (show) View.VISIBLE else View.GONE
            val imm = requireContext().getSystemService(InputMethodManager::class.java)
            if (show) {
                b.search.requestFocus()
                imm?.showSoftInput(b.search, 0)
            } else {
                b.search.setText("")
                imm?.hideSoftInputFromWindow(b.search.windowToken, 0)
            }
        }
        b.search.doAfterTextChanged { query = it?.toString().orEmpty(); refresh() }

        when (mode) {
            MODE_HOME, MODE_LIVE -> b.btnGroup.setOnClickListener { chooseGroup() }
            MODE_HISTORY -> {
                b.btnGroup.setText(R.string.clear)
                b.btnGroup.setOnClickListener {
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage(R.string.confirm_clear_history)
                        .setPositiveButton(R.string.ok) { _, _ -> Store.clearHistory() }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }
            }
            else -> b.btnGroup.visibility = View.GONE
        }

        if (mode == MODE_LIVE) {
            b.liveBar.setOnClickListener { if (!Store.checking.value) Store.checkLive(force = true) }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Store.channels.collect { ensureLive(); refresh() } }
                launch { Store.favorites.collect { refresh() } }
                launch { Store.history.collect { refresh() } }
                launch { Store.groupFilter.collect { refresh() } }
                launch { Store.liveGroup.collect { refresh() } }
                launch { Store.playingUrl.collect { refresh() } }
                launch { Store.activeId.collect { refresh() } }
                launch { Store.working.collect { refresh() } }
                launch { Store.checking.collect { refresh() } }
                launch { Store.checkProgress.collect { updateLiveBar() } }
                launch { Store.liveStamp.collect { ensureLive() } }
                launch {
                    Store.loading.collect { b.progress.visibility = if (it) View.VISIBLE else View.GONE }
                }
            }
        }
    }

    private fun liveOn() = mode == MODE_LIVE && Prefs.liveOnlyWorking

    private fun ensureLive() {
        if (liveOn()) Store.checkLive()
    }

    private fun applyLayoutMode() {
        adapter.grid = grid
        b.list.layoutManager =
            if (grid) GridLayoutManager(requireContext(), 2) // 2 cols ≈ 6–8 channels on screen with logos
            else LinearLayoutManager(requireContext())
        b.list.adapter = adapter
        b.btnGrid.setImageResource(if (grid) R.drawable.ic_list else R.drawable.ic_grid)
    }

    /** The channels this screen starts from (before category and search). */
    private fun baseChannels(): List<Channel> {
        val all = Store.channels.value
        return if (liveOn()) {
            val ok = Store.working.value
            all.filter { it.url in ok }
        } else all
    }

    private fun currentGroup(): String =
        if (mode == MODE_LIVE) Store.liveGroup.value else Store.groupFilter.value

    private fun refresh() {
        if (_b == null) return
        val favs = Store.favorites.value
        val playing = Store.playingUrl.value
        val group = currentGroup()
        val q = query.trim()

        val base: List<Channel> = when (mode) {
            MODE_FAV -> Store.channels.value.filter { it.url in favs }
            MODE_HISTORY -> Store.history.value
            else -> baseChannels().filter { group == Store.GROUP_ALL || it.group == group }
        }
        val list = base.filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
        shown = list.map { ChannelItem(it, it.url in favs, it.url == playing) }
        adapter.submitList(shown)

        val title = when (mode) {
            MODE_FAV -> getString(R.string.nav_fav)
            MODE_HISTORY -> getString(R.string.nav_history)
            MODE_LIVE -> getString(R.string.nav_live)
            else -> Store.activeName.ifEmpty { getString(R.string.nav_home) }
        }
        b.title.text = getString(R.string.title_count, title, list.size)

        if (mode == MODE_HOME || mode == MODE_LIVE) {
            b.btnGroup.text =
                if (group == Store.GROUP_ALL) getString(R.string.group_all) else group
        }

        val noPlaylist = (mode == MODE_HOME || mode == MODE_LIVE) &&
            Store.channels.value.isEmpty() && Store.playlists.value.isEmpty()
        b.empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        b.empty.setText(
            when {
                noPlaylist -> R.string.no_playlist
                liveOn() && Store.checking.value -> R.string.live_wait
                liveOn() && Store.channels.value.isNotEmpty() && q.isEmpty() -> R.string.live_none
                else -> R.string.no_results
            }
        )
        updateLiveBar()
    }

    private fun updateLiveBar() {
        if (_b == null) return
        val show = liveOn() && Store.channels.value.isNotEmpty()
        b.liveBar.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        val (done, total) = Store.checkProgress.value
        val okCount = Store.working.value.size
        if (Store.checking.value) {
            b.liveText.text = getString(R.string.live_checking, done, total, okCount)
            b.liveProgress.visibility = View.VISIBLE
            b.liveProgress.max = total.coerceAtLeast(1)
            b.liveProgress.progress = done
        } else {
            b.liveText.text = getString(R.string.live_done, okCount, Store.channels.value.map { it.url }.distinct().size)
            b.liveProgress.visibility = View.GONE
        }
    }

    private fun chooseGroup() {
        val all = baseChannels()
        val groups = all.groupingBy { it.group }.eachCount().toSortedMap()
        val names = ArrayList<String>()
        val labels = ArrayList<String>()
        names += Store.GROUP_ALL
        labels += "${getString(R.string.group_all)} (${all.size})"
        groups.forEach { (g, n) -> names += g; labels += "$g ($n)" }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.categories)
            .setItems(labels.toTypedArray()) { _, which ->
                if (mode == MODE_LIVE) Store.liveGroup.value = names[which]
                else Store.groupFilter.value = names[which]
            }
            .show()
    }

    private fun play(position: Int) {
        if (position !in shown.indices) return
        (requireActivity() as MainActivity).play(shown.map { it.channel }, position)
    }

    override fun onDestroyView() {
        _b = null
        super.onDestroyView()
    }

    companion object {
        const val MODE_HOME = 0
        const val MODE_FAV = 1
        const val MODE_HISTORY = 2
        const val MODE_LIVE = 3

        fun newInstance(mode: Int) = ChannelsFragment().apply { arguments = bundleOf("mode" to mode) }
    }
}
