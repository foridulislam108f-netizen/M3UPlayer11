package com.example.m3uplayer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.m3uplayer.databinding.FragmentPlaylistsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

/** "Saved files" screen: back arrow, title with count, + button, rows with count / edit / delete. */
class PlaylistsFragment : Fragment(R.layout.fragment_playlists) {

    private var _b: FragmentPlaylistsBinding? = null
    private val b get() = _b!!

    private val adapter = PlaylistAdapter(
        onPick = {
            if (it.id == Store.ALL_PLAYLISTS_ID) Store.activateAll()
            else Store.activate(it.id)
        },
        onEdit = { if (it.id != Store.ALL_PLAYLISTS_ID) askEdit(it) },
        onDelete = { p ->
            if (p.id != Store.ALL_PLAYLISTS_ID) {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(p.name)
                    .setMessage(R.string.confirm_delete_playlist)
                    .setPositiveButton(R.string.delete) { _, _ -> Store.remove(p.id) }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _b = FragmentPlaylistsBinding.bind(view)
        b.list.layoutManager = LinearLayoutManager(requireContext())
        b.list.adapter = adapter

        b.btnBack.setOnClickListener { (requireActivity() as MainActivity).showTab(0) }
        b.btnAdd.setOnClickListener { (requireActivity() as MainActivity).showAddSheet() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { Store.playlists.collect { submit() } }
                launch { Store.activeId.collect { submit() } }
                launch {
                    Store.loading.collect { b.progress.visibility = if (it) View.VISIBLE else View.GONE }
                }
            }
        }
    }

    private fun submit() {
        if (_b == null) return
        val active = Store.activeId.value
        val real = Store.playlists.value
        // Synthetic "All playlists" row when more than one playlist exists
        val items = buildList {
            if (real.size > 1) {
                add(
                    PlaylistInfo(
                        Store.ALL_PLAYLISTS_ID,
                        getString(R.string.all_playlists),
                        "",
                        false,
                        real.sumOf { it.count }
                    ) to (active == Store.ALL_PLAYLISTS_ID)
                )
            }
            real.forEach { add(it to (it.id == active)) }
        }
        adapter.submitList(items)
        b.title.text = getString(R.string.saved_files, real.size)
        b.empty.visibility = if (real.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun askEdit(p: PlaylistInfo) {
        val v = layoutInflater.inflate(R.layout.dialog_add_url, null)
        val name = v.findViewById<EditText>(R.id.inputName)
        val url = v.findViewById<EditText>(R.id.inputUrl)
        name.setText(p.name)
        if (p.isUrl) url.setText(p.source) else url.visibility = View.GONE
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.edit_playlist)
            .setView(v)
            .setPositiveButton(R.string.save) { _, _ ->
                Store.edit(p.id, name.text.toString().trim(), url.text.toString().trim())
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        _b = null
        super.onDestroyView()
    }

    private class PlaylistAdapter(
        private val onPick: (PlaylistInfo) -> Unit,
        private val onEdit: (PlaylistInfo) -> Unit,
        private val onDelete: (PlaylistInfo) -> Unit
    ) : ListAdapter<Pair<PlaylistInfo, Boolean>, PlaylistAdapter.VH>(Diff) {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val row: View = v
            val name: TextView = v.findViewById(R.id.name)
            val updated: TextView = v.findViewById(R.id.updated)
            val count: TextView = v.findViewById(R.id.count)
            val edit: ImageButton = v.findViewById(R.id.btnEdit)
            val delete: ImageButton = v.findViewById(R.id.btnDelete)
        }

        private val dateFmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_playlist, parent, false))

        override fun onBindViewHolder(h: VH, position: Int) {
            val (p, active) = getItem(position)
            h.name.text = p.name
            h.count.text = p.count.toString()
            if (p.updatedAt > 0L) {
                h.updated.visibility = View.VISIBLE
                h.updated.text = dateFmt.format(Date(p.updatedAt))
            } else {
                h.updated.visibility = View.GONE
            }
            h.row.isActivated = active
            h.row.setOnClickListener { onPick(p) }
            val isAll = p.id == Store.ALL_PLAYLISTS_ID
            h.edit.visibility = if (isAll) View.GONE else View.VISIBLE
            h.delete.visibility = if (isAll) View.GONE else View.VISIBLE
            h.edit.setOnClickListener { onEdit(p) }
            h.delete.setOnClickListener { onDelete(p) }
        }

        private object Diff : DiffUtil.ItemCallback<Pair<PlaylistInfo, Boolean>>() {
            override fun areItemsTheSame(a: Pair<PlaylistInfo, Boolean>, b: Pair<PlaylistInfo, Boolean>) =
                a.first.id == b.first.id
            override fun areContentsTheSame(a: Pair<PlaylistInfo, Boolean>, b: Pair<PlaylistInfo, Boolean>) = a == b
        }
    }
}
