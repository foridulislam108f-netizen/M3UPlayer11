package com.example.m3uplayer

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.audiofx.LoudnessEnhancer
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Owns the ExoPlayer. Because the player lives in a foreground "media" service,
 * audio keeps playing when the screen is off or the app is in the background.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    inner class LocalBinder : Binder() {
        val service: PlaybackService get() = this@PlaybackService
    }

    private val binder = LocalBinder()
    private val handler = Handler(Looper.getMainLooper())
    private var session: MediaSession? = null
    private var retries = 0
    private var enhancer: LoudnessEnhancer? = null

    lateinit var player: ExoPlayer
        private set

    /** Called on the main thread when the player was rebuilt (settings changed). */
    var onPlayerChanged: ((ExoPlayer) -> Unit)? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "audio_decoder" -> { soundRepair = false; rebuild() }
            "buffer_mode", "user_agent", "audio_focus", null -> rebuild()
            "volume_boost" -> setupEnhancer(player.audioSessionId)
            "max_quality" -> applyTrackPrefs(player)
            else -> Unit
        }
    }

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val p = player
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            // Sound problem (no sound / crackling / decoder crash): switch to the FFmpeg
            // software decoder once and retry, without the user touching anything.
            if (Prefs.autoSoundFix && !soundRepair && Prefs.audioDecoder != "ffmpeg" && isAudioError(error)) {
                soundRepair = true
                Store.status.value = getString(R.string.sound_repair)
                handler.post { rebuild() }
                return
            }
            // Some providers block the default User-Agent. Rotate through common UAs
            // once before normal retries (only when the user did not set a fixed UA).
            if (Prefs.autoRotateUa && isLikelyUaBlock(error) && uaIndex < Prefs.FALLBACK_USER_AGENTS.lastIndex) {
                uaIndex++
                Store.status.value = getString(R.string.trying_ua, uaIndex + 1, Prefs.FALLBACK_USER_AGENTS.size)
                handler.post { rebuild() }
                return
            }
            val max = Prefs.retries
            if (retries < max) {
                retries++
                Store.status.value = getString(R.string.reconnecting, retries, max)
                handler.postDelayed({ player.prepare() }, 2000)
            } else {
                Store.status.value = getString(R.string.cant_play, error.errorCodeName)
                if (Prefs.skipBroken && p.hasNextMediaItem()) {
                    handler.postDelayed({
                        if (player.hasNextMediaItem()) {
                            player.seekToNextMediaItem()
                            player.prepare()
                        }
                    }, 1500)
                }
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_READY) {
                retries = 0
                // Keep a working rotated UA for the rest of this channel;
                // reset only when the media item changes.
                Store.status.value = ""
            }
        }

        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
            retries = 0
            uaIndex = 0
            Store.status.value = ""
            handler.removeCallbacksAndMessages(null)
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            setupEnhancer(audioSessionId)
        }
    }

    override fun onCreate() {
        super.onCreate()
        player = buildPlayer(this)
        player.addListener(listener)
        session = MediaSession.Builder(this, player)
            .setSessionActivity(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()
        Prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onBind(intent: Intent?): IBinder? =
        if (intent?.action == ACTION_LOCAL) binder else super.onBind(intent)

    /** Swipe the app away: keep playing only if the user was listening. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady || !Prefs.backgroundPlay) {
            player.pause()
            stopSelf()
        }
    }

    override fun onDestroy() {
        Prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        handler.removeCallbacksAndMessages(null)
        try { enhancer?.release() } catch (_: Exception) { }
        session?.release()
        session = null
        player.removeListener(listener)
        player.release()
        super.onDestroy()
    }

    /** Re-create the player so new decoder / buffer settings apply immediately. */
    private fun rebuild() {
        val old = player
        val items = (0 until old.mediaItemCount).map { old.getMediaItemAt(it) }
        val index = old.currentMediaItemIndex
        val play = old.playWhenReady
        old.removeListener(listener)

        val np = buildPlayer(this)
        np.addListener(listener)
        session?.player = np
        player = np
        if (items.isNotEmpty()) {
            np.setMediaItems(items, index, C.TIME_UNSET)
            np.playWhenReady = play
            if (play) np.prepare()
        }
        old.release()
        setupEnhancer(np.audioSessionId)
        onPlayerChanged?.invoke(np)
    }

    private fun isAudioError(e: PlaybackException): Boolean {
        val code = e.errorCode
        if (code == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
            code == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED
        ) return true
        val decoderError = code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            code == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
        if (!decoderError) return false
        val mime = (e as? ExoPlaybackException)?.rendererFormat?.sampleMimeType
        return MimeTypes.isAudio(mime)
    }

    private fun setupEnhancer(sessionId: Int) {
        try {
            enhancer?.release()
            enhancer = null
            val db = Prefs.boostDb
            if (db > 0 && sessionId != C.AUDIO_SESSION_ID_UNSET && sessionId != 0) {
                enhancer = LoudnessEnhancer(sessionId).also {
                    it.setTargetGain(db * 100)
                    it.setEnabled(true)
                }
            }
        } catch (_: Exception) { }
    }

    companion object {
        const val ACTION_LOCAL = "com.example.m3uplayer.LOCAL_BIND"

        /** Set at runtime when a channel had an audio decoder error: prefer FFmpeg from then on. */
        @Volatile
        var soundRepair = false

        /**
         * Index into [Prefs.FALLBACK_USER_AGENTS] for the current channel.
         * Reset on media-item change; advanced on source/HTTP failures.
         */
        @Volatile
        var uaIndex: Int = 0

        /** Preferred audio language + max video height from Settings. */
        fun applyTrackPrefs(p: ExoPlayer) {
            val b = p.trackSelectionParameters.buildUpon()
            val q = Prefs.maxQuality
            if (q > 0) b.setMaxVideoSize(Int.MAX_VALUE, q)
            else b.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
            p.trackSelectionParameters = b.build()
        }

        private fun isLikelyUaBlock(e: PlaybackException): Boolean {
            val code = e.errorCode
            return code == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                code == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ||
                code == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ||
                code == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                code == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED ||
                code == PlaybackException.ERROR_CODE_IO_UNSPECIFIED
        }

        private fun effectiveUserAgent(): String {
            if (!Prefs.autoRotateUa) return Prefs.userAgent
            val list = Prefs.FALLBACK_USER_AGENTS
            val i = uaIndex.coerceIn(0, list.lastIndex)
            return list[i]
        }

        fun buildPlayer(ctx: Context): ExoPlayer {
            val http = DefaultHttpDataSource.Factory()
                .setUserAgent(effectiveUserAgent())
                .setAllowCrossProtocolRedirects(true)
                // Shorter timeouts → fail/retry faster on dead IPTV links
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(10000)

            // More tolerant MPEG-TS parsing = fewer silent / broken IPTV streams
            val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
                    DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS
            )
            val sources = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http), extractors)

            // FFmpeg software decoder is picked automatically when the phone can't decode a
            // codec (AC3 / E-AC3 / DTS ...). "ffmpeg" mode prefers it over hardware decoders.
            val renderers = DefaultRenderersFactory(ctx)
                .setExtensionRendererMode(
                    if (Prefs.audioDecoder == "ffmpeg" || soundRepair) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                    else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                )
                .setEnableDecoderFallback(true)

            // IPTV / live: start playback as soon as a little data is buffered
            val load = when (Prefs.bufferMode) {
                "low" -> DefaultLoadControl.Builder()
                    .setBufferDurationsMs(/*min*/1500, /*max*/8000, /*playback*/500, /*rebuffer*/1000)
                "stable" -> DefaultLoadControl.Builder()
                    .setBufferDurationsMs(8000, 40000, 2000, 4000)
                else -> DefaultLoadControl.Builder()
                    .setBufferDurationsMs(2500, 15000, 800, 1500)
            }.build()

            val player = ExoPlayer.Builder(ctx, renderers)
                .setMediaSourceFactory(sources)
                .setLoadControl(load)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    Prefs.audioFocus
                )
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()
            applyTrackPrefs(player)
            return player
        }
    }
}
