package com.example.m3uplayer

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** App settings (SharedPreferences). */
object Prefs {
    const val DEFAULT_UA = "Mozilla/5.0 (Linux; Android 13) M3UPlayer/3.0"

    val FALLBACK_USER_AGENTS = listOf(
        DEFAULT_UA,
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "VLC/3.0.20 LibVLC/3.0.20",
        "Lavf/60.16.100",
        "ExoPlayer",
        "IPTV Smarters Pro"
    )

    lateinit var sp: SharedPreferences
        private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences(ctx.packageName + "_preferences", Context.MODE_PRIVATE)
    }

    val language: String get() = sp.getString("language", "system") ?: "system"
    val theme: String get() = sp.getString("theme", "dark") ?: "dark"
    /** Color palette key: default | brown_mint | brown_beige | maroon_pink */
    val colorScheme: String get() = sp.getString("color_scheme", "default") ?: "default"
    val backgroundPlay: Boolean get() = sp.getBoolean("background_play", true)
    val keepScreenOn: Boolean get() = sp.getBoolean("keep_screen_on", true)
    val autoPip: Boolean get() = sp.getBoolean("auto_pip", false)
    val autoplayLast: Boolean get() = sp.getBoolean("autoplay_last", false)
    val autoRefresh: Boolean get() = sp.getBoolean("auto_refresh", false)
    val resizeMode: String get() = sp.getString("resize_mode", "fit") ?: "fit"
    val retries: Int get() = sp.getString("retries", "5")?.toIntOrNull() ?: 5
    val bufferMode: String get() = sp.getString("buffer_mode", "balanced") ?: "balanced"
    val audioDecoder: String get() = sp.getString("audio_decoder", "auto") ?: "auto"
    val boostDb: Int get() = sp.getString("volume_boost", "0")?.toIntOrNull() ?: 0
    val audioFocus: Boolean get() = sp.getBoolean("audio_focus", true)
    val autoSoundFix: Boolean get() = sp.getBoolean("auto_sound_fix", true)
    val skipBroken: Boolean get() = sp.getBoolean("skip_broken", false)
    val maxQuality: Int get() = sp.getString("max_quality", "0")?.toIntOrNull() ?: 0
    val liveOnlyWorking: Boolean get() = sp.getBoolean("live_only_working", true)
    val showLogos: Boolean get() = sp.getBoolean("show_logos", true)
    val controlsTimeoutMs: Int get() = (sp.getString("controls_timeout", "5")?.toIntOrNull() ?: 5) * 1000
    val textScale: Float
        get() = when (sp.getString("text_size", "normal")) {
            "small" -> 0.88f
            "large" -> 1.15f
            "xlarge" -> 1.3f
            else -> 1f
        }
    /** Logo / icon scale — same control as text size. */
    val logoScale: Float get() = textScale

    val customUserAgent: String
        get() = sp.getString("user_agent", "")?.trim().orEmpty()
    val userAgent: String
        get() = customUserAgent.ifBlank { DEFAULT_UA }
    val autoRotateUa: Boolean get() = customUserAgent.isBlank()

    // Player control bar toggles (Settings → M3U Player header)
    fun ctrl(key: String, default: Boolean = true): Boolean = sp.getBoolean("ctrl_$key", default)
    val ctrlTitle: Boolean get() = ctrl("title")
    val ctrlLiveBadge: Boolean get() = ctrl("live_badge")
    val ctrlFullscreen: Boolean get() = ctrl("fullscreen")
    val ctrlQuality: Boolean get() = ctrl("quality")
    val ctrlPrev: Boolean get() = ctrl("prev")
    val ctrlPlayPause: Boolean get() = ctrl("play_pause")
    val ctrlNext: Boolean get() = ctrl("next")
    val ctrlMore: Boolean get() = ctrl("more", default = false)  // ⋮ removed by default
    val ctrlSeek10: Boolean get() = ctrl("seek10")
    val ctrlTimeBar: Boolean get() = ctrl("time_bar")
    val ctrlPosition: Boolean get() = ctrl("position")

    /** Primary accent (icons, switches on, chips). */
    fun accentColor(): Int = when (colorScheme) {
        "brown_mint" -> Color.parseColor("#2A9D8F")      // mint
        "brown_beige" -> Color.parseColor("#C4A484")     // beige
        "maroon_pink" -> Color.parseColor("#E91E8C")     // pink
        else -> Color.parseColor("#6C5CE7")               // default purple
    }

    /** Secondary / soft accent (tracks, logo chip bg tint). */
    fun accentSoftColor(): Int = when (colorScheme) {
        "brown_mint" -> Color.parseColor("#8B5E3C")      // brown
        "brown_beige" -> Color.parseColor("#6B4423")     // brown
        "maroon_pink" -> Color.parseColor("#800020")     // maroon
        else -> Color.parseColor("#4F8DF7")
    }
}
