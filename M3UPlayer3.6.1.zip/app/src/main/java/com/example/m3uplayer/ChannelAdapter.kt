package com.example.m3uplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load

data class ChannelItem(val channel: Channel, val fav: Boolean, val playing: Boolean)

class ChannelAdapter(
    private val onClick: (Int) -> Unit,
    private val onFav: (Channel) -> Unit
) : ListAdapter<ChannelItem, ChannelAdapter.VH>(Diff) {

    /** false = list rows, true = 3-column grid */
    var grid = false

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val logo: ImageView = v.findViewById(R.id.logo)
        val name: TextView = v.findViewById(R.id.name)
        val fav: ImageButton = v.findViewById(R.id.fav)
    }

    override fun getItemViewType(position: Int) = if (grid) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 1) R.layout.item_channel_grid else R.layout.item_channel
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        // Content scale only (Settings + bottom nav stay fixed sizes)
        val scale = Prefs.textScale
        h.name.text = item.channel.name
        h.name.textSize = (if (grid) 13f else 15f) * scale
        h.itemView.isActivated = item.playing
        h.logo.visibility = if (Prefs.showLogos) View.VISIBLE else View.GONE
        if (Prefs.showLogos) {
            val baseDp = if (grid) 72f else 36f
            val base = (baseDp * h.logo.resources.displayMetrics.density * Prefs.logoScale).toInt()
            h.logo.layoutParams = h.logo.layoutParams.apply {
                width = base
                height = base
            }
            if (item.channel.logo.isBlank()) {
                h.logo.setImageResource(R.drawable.ph_logo)
            } else {
                h.logo.load(item.channel.logo) {
                    placeholder(R.drawable.ph_logo)
                    error(R.drawable.ph_logo)
                }
            }
        }
        h.fav.setImageResource(if (item.fav) R.drawable.ic_star else R.drawable.ic_star_outline)
        h.itemView.setOnClickListener {
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(pos)
        }
        h.fav.setOnClickListener { onFav(item.channel) }
    }

    private object Diff : DiffUtil.ItemCallback<ChannelItem>() {
        override fun areItemsTheSame(a: ChannelItem, b: ChannelItem) =
            a.channel.url == b.channel.url && a.channel.name == b.channel.name
        override fun areContentsTheSame(a: ChannelItem, b: ChannelItem) = a == b
    }
}
