package com.example.m3uplayer

object M3uParser {
    private val attrRegex = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        // Rough pre-size from #EXTINF count → fewer ArrayList growth copies
        var estimate = 0
        var i = 0
        while (true) {
            val j = text.indexOf("#EXTINF", i, ignoreCase = true)
            if (j < 0) break
            estimate++
            i = j + 7
        }
        val out = ArrayList<Channel>(estimate.coerceAtLeast(16))
        var name: String? = null
        var logo = ""
        var group = ""

        for (raw in text.lineSequence()) {
            val line = raw.trim().removePrefix("\uFEFF")
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    logo = ""; group = ""; name = null
                    // Fast path: only scan attrs if present
                    if (line.contains("tvg-logo", ignoreCase = true) ||
                        line.contains("group-title", ignoreCase = true) ||
                        line.contains("tvg-name", ignoreCase = true)
                    ) {
                        for (m in attrRegex.findAll(line)) {
                            when (m.groupValues[1].lowercase()) {
                                "tvg-logo" -> logo = m.groupValues[2]
                                "group-title" -> group = m.groupValues[2]
                                "tvg-name" -> if (name.isNullOrEmpty()) name = m.groupValues[2]
                            }
                        }
                    }
                    val comma = line.lastIndexOf(',')
                    if (comma >= 0) {
                        val n = line.substring(comma + 1).trim()
                        if (n.isNotEmpty()) name = n
                    }
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                    if (group.isEmpty()) group = line.substringAfter(':').trim()
                }
                line.startsWith("#") -> Unit
                else -> {
                    val title = name?.takeIf { it.isNotEmpty() }
                        ?: line.substringAfterLast('/').substringBefore('?')
                    out += Channel(title, line, logo, group.ifEmpty { "Other" })
                    name = null; logo = ""; group = ""
                }
            }
        }
        return out
    }
}
