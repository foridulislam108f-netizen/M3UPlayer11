package com.example.m3uplayer

import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Custom settings screen (no PreferenceFragmentCompat).
 * Preference library was crashing on some devices when opening Settings.
 */
class SettingsFragment : Fragment() {

    private lateinit var container: LinearLayout

    override fun onCreateView(inflater: LayoutInflater, parent: ViewGroup?, state: Bundle?): View {
        return inflater.inflate(R.layout.fragment_settings, parent, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        container = view.findViewById(R.id.container)
        try {
            buildUi()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Settings error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun buildUi() {
        container.removeAllViews()
        val ctx = requireContext()
        val dens = resources.displayMetrics.density

        // Header
        addHeader("M3U Player", "v${BuildConfig.VERSION_NAME} · ${getString(R.string.set_player_controls)}") {
            showPlayerControlsMenu()
        }

        addCategory(getString(R.string.set_playlist))
        addClickRow(R.drawable.ic_plus, getString(R.string.set_add_playlist), getString(R.string.set_add_playlist_sum)) {
            (activity as? MainActivity)?.showAddSheet()
        }
        addSwitchRow(
            R.drawable.ic_live_check, getString(R.string.set_live_only), getString(R.string.set_live_only_sum),
            Prefs.liveOnlyWorking
        ) { Prefs.sp.edit().putBoolean("live_only_working", it).apply() }
        addClickRow(R.drawable.ic_refresh2, getString(R.string.set_recheck_live), getString(R.string.set_recheck_live_sum)) {
            Store.checkLive(force = true)
            toast(R.string.done)
        }
        addSwitchRow(
            R.drawable.ic_download, getString(R.string.set_auto_refresh), getString(R.string.set_auto_refresh_sum),
            Prefs.autoRefresh
        ) { Prefs.sp.edit().putBoolean("auto_refresh", it).apply() }

        addCategory(getString(R.string.set_general))
        addChoiceRow(
            R.drawable.ic_globe, getString(R.string.set_language),
            arrayOf("System", "English", "বাংলা"),
            arrayOf("system", "en", "bn"),
            Prefs.language
        ) {
            Prefs.sp.edit().putString("language", it).commit()
            App.applyLanguage()
        }
        addChoiceRow(
            R.drawable.ic_theme, getString(R.string.set_theme),
            arrayOf("System", "Light", "Dark"),
            arrayOf("system", "light", "dark"),
            Prefs.theme
        ) {
            Prefs.sp.edit().putString("theme", it).commit()
            App.applyTheme()
        }
        addChoiceRow(
            R.drawable.ic_theme, getString(R.string.set_color_scheme),
            arrayOf(
                "Default (Purple)",
                "Brown + Mint",
                "Brown + Beige",
                "Maroon + Pink"
            ),
            arrayOf("default", "brown_mint", "brown_beige", "maroon_pink"),
            Prefs.colorScheme
        ) {
            Prefs.sp.edit().putString("color_scheme", it).commit()
            activity?.recreate()
        }
        addChoiceRow(
            R.drawable.ic_text_size, getString(R.string.set_text_size),
            arrayOf("Small", "Normal", "Large", "Extra large"),
            arrayOf("small", "normal", "large", "xlarge"),
            Prefs.sp.getString("text_size", "normal") ?: "normal"
        ) {
            Prefs.sp.edit().putString("text_size", it).commit()
            activity?.recreate()
        }
        addSwitchRow(
            R.drawable.ic_image, getString(R.string.set_show_logos), getString(R.string.set_show_logos_sum),
            Prefs.showLogos
        ) { Prefs.sp.edit().putBoolean("show_logos", it).apply() }

        addCategory(getString(R.string.set_player))
        addChoiceRow(
            R.drawable.ic_quality, getString(R.string.set_max_quality),
            arrayOf("Auto", "360p", "480p", "720p", "1080p", "1440p"),
            arrayOf("0", "360", "480", "720", "1080", "1440"),
            Prefs.sp.getString("max_quality", "0") ?: "0"
        ) { Prefs.sp.edit().putString("max_quality", it).apply() }
        addChoiceRow(
            R.drawable.ic_aspect, getString(R.string.set_resize),
            arrayOf("Fit", "Fill", "Zoom"),
            arrayOf("fit", "fill", "zoom"),
            Prefs.resizeMode
        ) { Prefs.sp.edit().putString("resize_mode", it).apply() }
        addSwitchRow(
            R.drawable.ic_headphones, getString(R.string.set_background_play), getString(R.string.set_background_play_sum),
            Prefs.backgroundPlay
        ) { Prefs.sp.edit().putBoolean("background_play", it).apply() }
        addSwitchRow(
            R.drawable.ic_bulb, getString(R.string.set_keep_screen_on), null,
            Prefs.keepScreenOn
        ) { Prefs.sp.edit().putBoolean("keep_screen_on", it).apply() }
        addSwitchRow(
            R.drawable.ic_pip, getString(R.string.set_auto_pip), getString(R.string.set_auto_pip_sum),
            Prefs.autoPip
        ) { Prefs.sp.edit().putBoolean("auto_pip", it).apply() }
        addSwitchRow(
            R.drawable.ic_play_circle, getString(R.string.set_autoplay_last), null,
            Prefs.autoplayLast
        ) { Prefs.sp.edit().putBoolean("autoplay_last", it).apply() }
        addChoiceRow(
            R.drawable.ic_timer, getString(R.string.set_controls_timeout),
            arrayOf("3s", "5s", "8s", "12s", "Never"),
            arrayOf("3", "5", "8", "12", "0"),
            Prefs.sp.getString("controls_timeout", "5") ?: "5"
        ) { Prefs.sp.edit().putString("controls_timeout", it).apply() }
        addChoiceRow(
            R.drawable.ic_refresh2, getString(R.string.set_retries),
            arrayOf("1", "3", "5", "8", "12"),
            arrayOf("1", "3", "5", "8", "12"),
            Prefs.sp.getString("retries", "5") ?: "5"
        ) { Prefs.sp.edit().putString("retries", it).apply() }
        addChoiceRow(
            R.drawable.ic_gauge, getString(R.string.set_buffer),
            arrayOf("Low latency", "Balanced", "Stable"),
            arrayOf("low", "balanced", "stable"),
            Prefs.bufferMode
        ) { Prefs.sp.edit().putString("buffer_mode", it).apply() }
        addSwitchRow(
            R.drawable.ic_skip, getString(R.string.set_skip_broken), getString(R.string.set_skip_broken_sum),
            Prefs.skipBroken
        ) { Prefs.sp.edit().putBoolean("skip_broken", it).apply() }

        addCategory(getString(R.string.set_sound))
        addChoiceRow(
            R.drawable.ic_chip, getString(R.string.set_audio_decoder),
            arrayOf("Auto", "Hardware", "FFmpeg"),
            arrayOf("auto", "hw", "ffmpeg"),
            Prefs.audioDecoder
        ) { Prefs.sp.edit().putString("audio_decoder", it).apply() }
        addChoiceRow(
            R.drawable.ic_volume, getString(R.string.set_volume_boost),
            arrayOf("Off", "+3 dB", "+6 dB", "+9 dB", "+12 dB"),
            arrayOf("0", "3", "6", "9", "12"),
            Prefs.sp.getString("volume_boost", "0") ?: "0"
        ) { Prefs.sp.edit().putString("volume_boost", it).apply() }
        addSwitchRow(
            R.drawable.ic_wand, getString(R.string.set_auto_sound_fix), getString(R.string.set_auto_sound_fix_sum),
            Prefs.autoSoundFix
        ) { Prefs.sp.edit().putBoolean("auto_sound_fix", it).apply() }
        addSwitchRow(
            R.drawable.ic_pause_circle, getString(R.string.set_audio_focus), getString(R.string.set_audio_focus_sum),
            Prefs.audioFocus
        ) { Prefs.sp.edit().putBoolean("audio_focus", it).apply() }

        addCategory(getString(R.string.set_network))
        addClickRow(R.drawable.ic_globe, getString(R.string.set_user_agent), Prefs.customUserAgent.ifBlank { getString(R.string.set_user_agent_sum) }) {
            askText(getString(R.string.set_user_agent), Prefs.customUserAgent) { v ->
                Prefs.sp.edit().putString("user_agent", v).apply()
                toast(R.string.done)
                buildUi()
            }
        }

        addCategory(getString(R.string.set_data))
        addClickRow(R.drawable.ic_trash, getString(R.string.set_clear_history), null) {
            confirm(R.string.confirm_clear_history) { Store.clearHistory(); toast(R.string.done) }
        }
        addClickRow(R.drawable.ic_trash, getString(R.string.set_clear_favorites), null) {
            confirm(R.string.confirm_clear_favorites) { Store.clearFavorites(); toast(R.string.done) }
        }
        addClickRow(R.drawable.ic_reset, getString(R.string.set_reset), getString(R.string.set_reset_sum)) {
            confirm(R.string.confirm_reset) {
                Prefs.sp.edit().clear().commit()
                App.applyTheme(); App.applyLanguage()
                toast(R.string.done)
                activity?.recreate()
            }
        }

        addCategory(getString(R.string.set_about))
        addClickRow(R.drawable.ic_settings, getString(R.string.set_version), "v${BuildConfig.VERSION_NAME}") {}
        addClickRow(R.drawable.ic_link2, getString(R.string.contact_us), "fab27121995@gmail.com") {
            try {
                startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:fab27121995@gmail.com")))
            } catch (_: Exception) {
                toast(R.string.done)
            }
        }
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPlayerControlsMenu() {
        val keys = listOf(
            "title" to R.string.ctrl_title,
            "live_badge" to R.string.ctrl_live_badge,
            "fullscreen" to R.string.ctrl_fullscreen,
            "quality" to R.string.ctrl_quality,
            "prev" to R.string.ctrl_prev,
            "play_pause" to R.string.ctrl_play_pause,
            "next" to R.string.ctrl_next,
            "seek10" to R.string.ctrl_seek10,
            "time_bar" to R.string.ctrl_time_bar,
            "position" to R.string.ctrl_position
        )
        val labels = keys.map { getString(it.second) }.toTypedArray()
        val checked = keys.map { Prefs.ctrl(it.first) }.toBooleanArray()
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.set_player_controls)
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                Prefs.sp.edit().putBoolean("ctrl_${keys[which].first}", isChecked).apply()
            }
            .setPositiveButton(R.string.ok, null)
            .show()
    }

    private fun addHeader(title: String, sub: String, onClick: (() -> Unit)? = null) {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = ContextCompat.getDrawable(context, R.drawable.bg_pref_row)
            isClickable = onClick != null
            isFocusable = onClick != null
            if (onClick != null) setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        val icon = ImageView(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            setImageResource(R.drawable.ic_app_logo_full)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = ContextCompat.getDrawable(context, R.drawable.bg_logo_app)
        }
        val texts = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(14)
            layoutParams = lp
            addView(TextView(context).apply {
                text = title
                setTextColor(ContextCompat.getColor(context, R.color.text))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            addView(TextView(context).apply {
                text = sub
                setTextColor(ContextCompat.getColor(context, R.color.text_dim))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
            })
        }
        row.addView(icon)
        row.addView(texts)
        container.addView(row)
    }

    private fun addCategory(title: String) {
        val tv = TextView(requireContext()).apply {
            text = title.uppercase()
            setTextColor(ContextCompat.getColor(context, R.color.accent))
            setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(12), dp(18), dp(12), dp(6))
            letterSpacing = 0.08f
        }
        container.addView(tv)
    }

    private fun makeRow(icon: Int, title: String, summary: String?): LinearLayout {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = ContextCompat.getDrawable(context, R.drawable.bg_pref_row)
            isClickable = true
            isFocusable = true
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(4)
            lp.bottomMargin = dp(4)
            layoutParams = lp
            minimumHeight = dp(64)
        }
        val iv = ImageView(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            setImageResource(icon)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            background = ContextCompat.getDrawable(context, R.drawable.bg_icon_chip)
            imageTintList = ColorStateList.valueOf(Prefs.accentColor())
        }
        val texts = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(14)
            layoutParams = lp
            addView(TextView(context).apply {
                text = title
                setTextColor(ContextCompat.getColor(context, R.color.text))
                setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            if (!summary.isNullOrBlank()) {
                addView(TextView(context).apply {
                    text = summary
                    setTextColor(ContextCompat.getColor(context, R.color.text_dim))
                    setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f)
                })
            }
        }
        row.addView(iv)
        row.addView(texts)
        return row
    }

    private fun addClickRow(icon: Int, title: String, summary: String?, onClick: () -> Unit) {
        val row = makeRow(icon, title, summary)
        row.setOnClickListener { onClick() }
        container.addView(row)
    }

    private fun addSwitchRow(icon: Int, title: String, summary: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = makeRow(icon, title, summary)
        val accent = Prefs.accentColor()
        val soft = Prefs.accentSoftColor()
        val sw = SwitchCompat(requireContext()).apply {
            isChecked = checked
            thumbTintList = ColorStateList.valueOf(accent)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(soft, 0x44FFFFFF)
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        row.addView(sw)
        row.setOnClickListener { sw.isChecked = !sw.isChecked }
        container.addView(row)
    }

    private fun addChoiceRow(
        icon: Int, title: String, labels: Array<String>, values: Array<String>,
        current: String, onPick: (String) -> Unit
    ) {
        val idx = values.indexOf(current).coerceAtLeast(0)
        val row = makeRow(icon, title, labels.getOrNull(idx))
        row.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(title)
                .setSingleChoiceItems(labels, values.indexOf(current).coerceAtLeast(0)) { d, which ->
                    onPick(values[which])
                    d.dismiss()
                    buildUi()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        container.addView(row)
    }

    private fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(requireContext()).apply {
            setText(initial)
            setSelection(text.length)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(title)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(input.text.toString().trim()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirm(msg: Int, action: () -> Unit) {
        MaterialAlertDialogBuilder(requireContext())
            .setMessage(msg)
            .setPositiveButton(R.string.ok) { _, _ -> action() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toast(res: Int) {
        Toast.makeText(requireContext(), res, Toast.LENGTH_SHORT).show()
    }
}
