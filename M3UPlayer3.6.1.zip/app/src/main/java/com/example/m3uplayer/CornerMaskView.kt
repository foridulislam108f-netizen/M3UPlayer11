package com.example.m3uplayer

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

/**
 * Draws the 4 rounded corners on top of a SurfaceView (which can't be clipped by an outline
 * on every Android version). The corner colour follows the app's background gradient.
 */
class CornerMaskView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var radiusPx: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rect = RectF()
    private val eval = ArgbEvaluator()
    private val loc = IntArray(2)
    private val rootLoc = IntArray(2)

    private fun bgAt(yInView: Float): Int {
        val root = rootView
        val rh = root.height.coerceAtLeast(1)
        getLocationInWindow(loc)
        root.getLocationInWindow(rootLoc)
        val f = ((loc[1] - rootLoc[1] + yInView) / rh).coerceIn(0f, 1f)
        val top = ContextCompat.getColor(context, R.color.bg_top)
        val bottom = ContextCompat.getColor(context, R.color.bg_bottom)
        return eval.evaluate(f, top, bottom) as Int
    }

    override fun onDraw(canvas: Canvas) {
        val r = radiusPx
        if (r <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val e = 1f // slight overdraw so no thin seam shows at the edge

        paint.color = bgAt(0f)
        // top-left
        path.reset()
        path.moveTo(-e, -e); path.lineTo(r, -e); path.lineTo(r, 0f)
        rect.set(0f, 0f, 2 * r, 2 * r); path.arcTo(rect, 270f, -90f)
        path.lineTo(-e, r); path.close()
        canvas.drawPath(path, paint)
        // top-right
        path.reset()
        path.moveTo(w + e, -e); path.lineTo(w + e, r); path.lineTo(w, r)
        rect.set(w - 2 * r, 0f, w, 2 * r); path.arcTo(rect, 0f, -90f)
        path.lineTo(w - r, -e); path.close()
        canvas.drawPath(path, paint)

        paint.color = bgAt(h)
        // bottom-left
        path.reset()
        path.moveTo(-e, h + e); path.lineTo(-e, h - r); path.lineTo(0f, h - r)
        rect.set(0f, h - 2 * r, 2 * r, h); path.arcTo(rect, 180f, -90f)
        path.lineTo(r, h + e); path.close()
        canvas.drawPath(path, paint)
        // bottom-right
        path.reset()
        path.moveTo(w + e, h + e); path.lineTo(w - r, h + e); path.lineTo(w - r, h)
        rect.set(w - 2 * r, h - 2 * r, w, h); path.arcTo(rect, 90f, -90f)
        path.lineTo(w + e, h - r); path.close()
        canvas.drawPath(path, paint)
    }
}
