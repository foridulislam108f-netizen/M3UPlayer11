package com.example.m3uplayer

import android.app.DownloadManager
import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Rational
import android.media.AudioManager
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.m3uplayer.databinding.ActivityMainBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private var service: PlaybackService? = null
    private var bound = false
    private val pendingActions = ArrayList<(ExoPlayer) -> Unit>()

    private var tab = 0
    private var fullscreen = false
    private var inPip = false
    private var portraitHeight = 0
    private var restoredLast = false
    private var lastHistoryUrl: String? = null
    private var askedNotification = false
    private var sleepRunnable: Runnable? = null
    private var sleepMin = 0
    private var menuPopup: PopupWindow? = null

    private val qualities = listOf(
        0 to "Auto",
        360 to "360p",
        480 to "480p",
        720 to "720p · HD",
        1080 to "1080p · Full HD",
        1440 to "1440p · 2K"
    )

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            uris.forEach { Store.addFile(it) }
        }

    private var resizeIndex = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )

    private val navItems by lazy {
        listOf(b.navHome, b.navLive, b.navFav, b.navHistory, b.navPlaylists, b.navSettings)
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            setFullscreen(false)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "resize_mode") applyResizeFromPrefs()
        if (key == "controls_timeout") applyControlsTimeout()
    }

    // ---------- service connection ----------

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as? PlaybackService.LocalBinder)?.service ?: return
            service = s
            s.onPlayerChanged = { np -> attach(np) }
            attach(s.player)
            val actions = ArrayList(pendingActions)
            pendingActions.clear()
            actions.forEach { it(s.player) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            detach()
            service = null
        }
    }

    // ---------- player events ----------

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNowPlaying()

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = updateNowPlaying()

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying && Prefs.keepScreenOn) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            if (isPlaying) {
                currentChannel()?.let {
                    if (it.url != lastHistoryUrl) {
                        lastHistoryUrl = it.url
                        Store.addHistory(it)
                    }
                }
            }
            updateNowPlaying()
        }
    }

    // ---------- lifecycle ----------

    /**
     * Text/logo size from Settings applies only to channel list content.
     * Settings icons and bottom navigation icons/labels stay fixed (not scaled).
     */
    private fun applyTextScale() {
        // Intentionally empty: global fontScale would also resize Settings + Nav.
        // ChannelAdapter applies Prefs.textScale / Prefs.logoScale to list items only.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTextScale()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setupPlayerBox()
        setupNav()
        setupPlayerButtons()
        onBackPressedDispatcher.addCallback(this, backCallback)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    Store.status.collect {
                        b.status.text = it
                        b.status.visibility = if (it.isEmpty()) View.GONE else View.VISIBLE
                    }
                }
                launch {
                    Store.messages.collect {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_LONG).show()
                    }
                }
                launch { Store.channels.collect { restoreLast(it) } }
            }
        }

        tab = savedInstanceState?.getInt("tab") ?: 0
        if (savedInstanceState == null) showTab(0) else updateNav()

        try {
            startService(Intent(this, PlaybackService::class.java))
        } catch (_: Exception) { }
        bound = bindService(
            Intent(this, PlaybackService::class.java).setAction(PlaybackService.ACTION_LOCAL),
            connection,
            Context.BIND_AUTO_CREATE
        )
        updateNowPlaying()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onStart() {
        super.onStart()
        Prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        player?.let { setVideoDisabled(it, false) }
    }

    override fun onStop() {
        super.onStop()
        Prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        val p = player ?: return
        if (Prefs.backgroundPlay) {
            setVideoDisabled(p, true)   // audio keeps playing, no video decoding while hidden
        } else {
            p.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        service?.onPlayerChanged = null
        detach()
        if (bound) {
            try { unbindService(connection) } catch (_: Exception) { }
            bound = false
        }
        super.onDestroy()
    }

    // ---------- player attach / helpers ----------

    private fun attach(p: ExoPlayer) {
        player?.removeListener(listener)
        player = p
        p.addListener(listener)
        b.playerView.player = p
        setVideoDisabled(p, false)
        updateNowPlaying()
    }

    private fun detach() {
        player?.removeListener(listener)
        b.playerView.player = null
        player = null
    }

    private fun withPlayer(block: (ExoPlayer) -> Unit) {
        val p = player
        if (p != null) block(p) else pendingActions += block
    }

    private fun setVideoDisabled(p: ExoPlayer, disabled: Boolean) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, disabled)
            .build()
    }

    private fun toMediaItem(c: Channel): MediaItem {
        // Skip artwork URI — loading logos into MediaMetadata slows first open on big lists
        val meta = MediaMetadata.Builder().setTitle(c.name).setArtist(c.group)
        return MediaItem.Builder()
            .setMediaId(c.url)
            .setUri(c.url)
            .setMediaMetadata(meta.build())
            .build()
    }

    /**
     * Only queue a small window around the tapped channel.
     * Loading 5–10k MediaItems at once was the main reason channels opened slowly.
     */
    private fun mediaWindow(list: List<Channel>, index: Int, radius: Int = 20): Pair<List<MediaItem>, Int> {
        val from = (index - radius).coerceAtLeast(0)
        val to = (index + radius + 1).coerceAtMost(list.size)
        val items = list.subList(from, to).map { toMediaItem(it) }
        return items to (index - from)
    }

    private fun currentChannel(): Channel? {
        val item = player?.currentMediaItem ?: return null
        val id = item.mediaId
        return Store.channels.value.firstOrNull { it.url == id }
            ?: Channel(item.mediaMetadata.title?.toString() ?: id, id, "", item.mediaMetadata.artist?.toString() ?: "")
    }

    /** Called by the list screens. */
    fun play(list: List<Channel>, index: Int) {
        if (index !in list.indices) return
        ensureNotificationPermission()
        try {
            startService(Intent(this, PlaybackService::class.java))
        } catch (_: Exception) { }
        val (items, start) = mediaWindow(list, index)
        withPlayer { p ->
            // Stop previous stream immediately so the new one can connect faster
            p.stop()
            p.setMediaItems(items, start, C.TIME_UNSET)
            p.playWhenReady = true
            p.prepare()
            b.overlay.visibility = View.VISIBLE
            scheduleHideOverlay()
        }
    }

    /** After the playlist loads, show the last channel as "Press play: ..." (without playing). */
    private fun restoreLast(list: List<Channel>) {
        if (restoredLast || list.isEmpty()) return
        restoredLast = true
        withPlayer { p ->
            if (p.mediaItemCount == 0) {
                val last = Store.lastUrl
                val idx = list.indexOfFirst { it.url == last }.coerceAtLeast(0)
                val (items, start) = mediaWindow(list, idx)
                p.setMediaItems(items, start, C.TIME_UNSET)
                if (Prefs.autoplayLast) {
                    p.playWhenReady = true
                    p.prepare()
                } else {
                    p.playWhenReady = false
                }
            }
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotification &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotification = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun updateNowPlaying() {
        val p = player
        val item = p?.currentMediaItem
        val name = item?.mediaMetadata?.title?.toString()
        Store.playingUrl.value = item?.mediaId
        b.title.text = name ?: getString(R.string.nothing_playing)
    }


    // ---------- layout / fullscreen / PiP ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupPlayerBox() {
        // Slight side inset only — player sits high, near the status bar / notch
        val m = dp(4)
        portraitHeight = ((resources.displayMetrics.widthPixels - 2 * m) * 9f / 16f).toInt()
        applyLayout()
        b.playerContainer.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = if (fullscreen || inPip) 0f else dp(24).toFloat()
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        b.playerContainer.clipToOutline = true
        applyResizeFromPrefs()
        applyControlsTimeout()
        // Custom overlay — show on start, auto-hide while playing
        b.overlay.visibility = View.VISIBLE
        scheduleHideOverlay()
    }

    private fun applyLayout() {
        val only = fullscreen || inPip
        val vis = if (only) View.GONE else View.VISIBLE
        b.fragmentContainer.visibility = vis
        b.nav.visibility = vis

        val lp = b.playerContainer.layoutParams as LinearLayout.LayoutParams
        if (only) {
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT
            lp.setMargins(0, 0, 0, 0)
        } else {
            lp.height = portraitHeight
            val side = dp(4)
            // top=0 → closer to notch; small left/right gap
            lp.setMargins(side, 0, side, dp(4))
        }
        b.playerContainer.layoutParams = lp
        b.playerContainer.invalidateOutline()
        b.btnFullscreen.setImageResource(
            if (fullscreen) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen
        )

        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (fullscreen) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
        backCallback.isEnabled = fullscreen
    }

    private fun setFullscreen(on: Boolean) {
        fullscreen = on
        requestedOrientation =
            if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        applyLayout()
    }

    private fun applyResizeFromPrefs() {
        resizeIndex = when (Prefs.resizeMode) {
            "fill" -> 1
            "zoom" -> 2
            else -> 0
        }
        b.playerView.resizeMode = resizeModes[resizeIndex]
    }

    private fun applyControlsTimeout() {
        b.playerView.controllerShowTimeoutMs = Prefs.controlsTimeoutMs
    }

    private fun enterPip() {
        if (packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (_: Exception) { }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Prefs.autoPip && player?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        b.overlay.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        applyLayout()
    }

    // ---------- navigation ----------

    private fun setupNav() {
        navItems.forEachIndexed { i, v ->
            v.setOnClickListener { if (i != tab) showTab(i) }
        }
    }

    private fun updateNav() {
        navItems.forEachIndexed { i, v -> v.isSelected = i == tab }
    }

    fun showTab(i: Int) {
        tab = i
        updateNav()
        val f: Fragment = when (i) {
            0 -> ChannelsFragment.newInstance(ChannelsFragment.MODE_HOME)
            1 -> ChannelsFragment.newInstance(ChannelsFragment.MODE_LIVE)
            2 -> ChannelsFragment.newInstance(ChannelsFragment.MODE_FAV)
            3 -> ChannelsFragment.newInstance(ChannelsFragment.MODE_HISTORY)
            4 -> PlaylistsFragment()
            else -> SettingsFragment()
        }
        supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, f).commit()
    }

    // ---------- player buttons / ⋮ menu ----------

    private class MenuRow(
        val icon: Int,
        val label: String,
        val value: String? = null,
        val checked: Boolean = false,
        val arrow: Boolean = false,
        val onClick: () -> Unit
    )

    private fun setupPlayerButtons() {
        b.btnFullscreen.setOnClickListener { setFullscreen(!fullscreen) }
        b.btnMore.setOnClickListener { showMoreMenu() }
        b.btnQuality.setOnClickListener { showQualityMenu() }
        b.btnPlayPause.setOnClickListener {
            withPlayer { p ->
                when {
                    // Not prepared yet (e.g. restored last channel) or stopped after an error
                    p.playbackState == Player.STATE_IDLE -> {
                        p.prepare()
                        p.play()
                    }
                    p.playbackState == Player.STATE_ENDED -> {
                        p.seekToDefaultPosition()
                        p.play()
                    }
                    p.playWhenReady -> p.pause()
                    else -> p.play()
                }
                scheduleHideOverlay()
            }
        }
        b.btnPrev.setOnClickListener {
            withPlayer { p ->
                if (p.hasPreviousMediaItem()) {
                    p.seekToPreviousMediaItem()
                    p.prepare()
                    p.play()
                }
            }
        }
        b.btnNext.setOnClickListener {
            withPlayer { p ->
                if (p.hasNextMediaItem()) {
                    p.seekToNextMediaItem()
                    p.prepare()
                    p.play()
                }
            }
        }
        // ±10 seconds — only for VOD (seekable)
        b.btnSeekBack.setOnClickListener {
            withPlayer { p ->
                if (p.isCurrentMediaItemSeekable) p.seekTo((p.currentPosition - 10_000).coerceAtLeast(0))
            }
        }
        b.btnSeekFwd.setOnClickListener {
            withPlayer { p ->
                if (p.isCurrentMediaItemSeekable) {
                    val dur = p.duration
                    val target = p.currentPosition + 10_000
                    p.seekTo(if (dur > 0 && dur != C.TIME_UNSET) target.coerceAtMost(dur) else target)
                }
            }
        }
        b.overlay.setOnClickListener { /* consume taps on controls */ }
        startProgressTicker()
        b.timeBar.addListener(object : androidx.media3.ui.TimeBar.OnScrubListener {
            override fun onScrubStart(timeBar: androidx.media3.ui.TimeBar, position: Long) {}
            override fun onScrubMove(timeBar: androidx.media3.ui.TimeBar, position: Long) {
                b.positionText.text = formatMs(position)
            }
            override fun onScrubStop(timeBar: androidx.media3.ui.TimeBar, position: Long, canceled: Boolean) {
                if (!canceled) player?.seekTo(position)
            }
        })
        setupPlayerGestures()
    }

    /**
     * Left half vertical swipe → brightness
     * Right half vertical swipe → volume
     * Single tap → show/hide controls
     */
    private fun setupPlayerGestures() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        var startY = 0f
        var startX = 0f
        var startVol = 0
        var startBright = 0f
        var mode = 0 // 0 none, 1 volume, 2 brightness
        val maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

        b.playerView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.y
                    startX = e.x
                    startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val lp = window.attributes
                    startBright = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                    mode = 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = startY - e.y
                    val dx = e.x - startX
                    if (mode == 0 && kotlin.math.abs(dy) > 24 && kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.2f) {
                        mode = if (startX > v.width / 2f) 1 else 2
                    }
                    when (mode) {
                        1 -> {
                            val delta = (dy / v.height) * maxVol * 1.4f
                            val nv = (startVol + delta).toInt().coerceIn(0, maxVol)
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
                            showGestureHint("🔊  ${(nv * 100 / maxVol)}%")
                        }
                        2 -> {
                            val delta = dy / v.height * 1.2f
                            val nb = (startBright + delta).coerceIn(0.01f, 1f)
                            val lp = window.attributes
                            lp.screenBrightness = nb
                            window.attributes = lp
                            showGestureHint("☀️  ${(nb * 100).toInt()}%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (mode == 0 && kotlin.math.abs(e.y - startY) < 16 && kotlin.math.abs(e.x - startX) < 16) {
                        toggleOverlay()
                    }
                    hideGestureHintSoon()
                    true
                }
                else -> false
            }
        }
    }

    private fun showGestureHint(text: String) {
        b.gestureHint.text = text
        b.gestureHint.visibility = View.VISIBLE
        handler.removeCallbacks(hideGestureRunnable)
    }

    private val hideGestureRunnable = Runnable { b.gestureHint.visibility = View.GONE }
    private fun hideGestureHintSoon() {
        handler.removeCallbacks(hideGestureRunnable)
        handler.postDelayed(hideGestureRunnable, 600)
    }

    private fun toggleOverlay() {
        if (b.overlay.visibility == View.VISIBLE) {
            b.overlay.visibility = View.GONE
            handler.removeCallbacks(hideOverlayRunnable)
        } else {
            b.overlay.visibility = View.VISIBLE
            scheduleHideOverlay()  // 3 seconds
        }
    }

    private fun scheduleHideOverlay() {
        handler.removeCallbacks(hideOverlayRunnable)
        // Touch shows controls for 3 seconds
        if (!inPip) {
            handler.postDelayed(hideOverlayRunnable, 3_000L)
        }
    }

    private val hideOverlayRunnable = Runnable {
        if (!inPip) b.overlay.visibility = View.GONE
    }

    private fun startProgressTicker() {
        handler.post(object : Runnable {
            override fun run() {
                updateProgressUi()
                handler.postDelayed(this, 500)
            }
        })
    }

    private fun formatMs(ms: Long): String {
        if (ms < 0 || ms == C.TIME_UNSET) return "00:00"
        val total = (ms / 1000).toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    /**
     * Live = no -10/+10 and no time bar. Counts as live when the stream says so, can't be
     * seeked, has no duration, or only has a tiny sliding window (a few minutes) like live TV.
     */
    private fun isLiveStream(p: ExoPlayer): Boolean {
        val dur = p.duration
        if (p.isCurrentMediaItemLive || !p.isCurrentMediaItemSeekable) return true
        if (dur <= 0 || dur == C.TIME_UNSET) return true
        return dur < 3 * 60_000L
    }

    private fun updateProgressUi() {
        val p = player ?: return
        val pos = p.currentPosition
        val dur = p.duration
        val live = isLiveStream(p)
        var noSeek = false
        if (live) {
            // Live: always show the bar + red LIVE. If the stream has a seekable window
            // (DVR / timeshift) the bar is scrubbable and shows time; otherwise a full, locked bar.
            val windowOk = p.isCurrentMediaItemSeekable && dur > 0 && dur != C.TIME_UNSET
            b.liveText.visibility = View.VISIBLE
            b.timeBar.visibility = View.VISIBLE
            if (windowOk) {
                b.positionText.visibility = View.VISIBLE
                b.durationText.visibility = View.VISIBLE
                b.positionText.text = formatMs(pos)
                b.durationText.text = formatMs(dur)
                b.timeBar.setEnabled(true)
                b.timeBar.setDuration(dur)
                b.timeBar.setPosition(pos)
                b.timeBar.setBufferedPosition(p.bufferedPosition)
                b.seekRow.visibility =
                    if (b.overlay.visibility == View.VISIBLE) View.VISIBLE else View.GONE
            } else {
                noSeek = true
                b.positionText.visibility = View.GONE
                b.durationText.visibility = View.GONE
                b.timeBar.setEnabled(false)
                b.timeBar.setDuration(1000)
                b.timeBar.setPosition(1000)
                b.timeBar.setBufferedPosition(1000)
                b.seekRow.visibility = View.GONE
            }
        } else {
            b.positionText.visibility = View.VISIBLE
            b.durationText.visibility = View.VISIBLE
            b.positionText.text = formatMs(pos)
            b.durationText.text = formatMs(dur)
            b.liveText.visibility = View.GONE
            b.timeBar.visibility = View.VISIBLE
            b.timeBar.setEnabled(true)
            b.timeBar.setDuration(dur)
            b.timeBar.setPosition(pos)
            b.timeBar.setBufferedPosition(p.bufferedPosition)
            // VOD: ±10s when controls visible
            b.seekRow.visibility =
                if (b.overlay.visibility == View.VISIBLE) View.VISIBLE else View.GONE
        }
        val showPause = p.playWhenReady &&
            (p.playbackState == Player.STATE_READY || p.playbackState == Player.STATE_BUFFERING)
        b.btnPlayPause.setImageResource(
            if (showPause) R.drawable.ic_pause_circle else R.drawable.ic_play_circle
        )
        // Real resolution of the video that is playing right now
        val vh = p.videoSize.height
        b.btnQuality.text = if (vh > 0) "${vh}p" else "Auto"
        applyControlVisibility(noSeek)
    }

    /** Show/hide each control from Settings → M3U Player. */
    private fun applyControlVisibility(live: Boolean) {
        val vis = { on: Boolean -> if (on) View.VISIBLE else View.GONE }
        b.title.visibility = vis(Prefs.ctrlTitle)
        b.btnFullscreen.visibility = vis(Prefs.ctrlFullscreen)
        b.btnQuality.visibility = vis(Prefs.ctrlQuality)
        b.btnPrev.visibility = vis(Prefs.ctrlPrev)
        b.btnPlayPause.visibility = vis(Prefs.ctrlPlayPause)
        b.btnNext.visibility = vis(Prefs.ctrlNext)
        b.btnMore.visibility = View.VISIBLE
        if (!Prefs.ctrlSeek10 || live) {
            b.seekRow.visibility = View.GONE
        }
        if (!Prefs.ctrlTimeBar) {
            b.timeBar.visibility = View.GONE
        }
        if (!Prefs.ctrlPosition) {
            b.positionText.visibility = View.GONE
            b.durationText.visibility = View.GONE
        }
    }

    private fun qualityLabel(): String =
        qualities.firstOrNull { it.first == Prefs.maxQuality }?.second ?: getString(R.string.quality_auto)

    private fun showMoreMenu() {
        val aspectNames = arrayOf(getString(R.string.fit), getString(R.string.fill), getString(R.string.zoom))
        showMenu(
            null,
            listOf(
                MenuRow(R.drawable.ic_audio, getString(R.string.audio_track), arrow = true) {
                    showTrackMenu(C.TRACK_TYPE_AUDIO, R.string.audio_track)
                },
                MenuRow(R.drawable.ic_aspect, getString(R.string.aspect_ratio), aspectNames[resizeIndex], arrow = true) {
                    showAspectMenu()
                },
                MenuRow(
                    R.drawable.ic_sleep, getString(R.string.sleep_timer),
                    if (sleepMin > 0) getString(R.string.sleep_minutes, sleepMin) else null, arrow = true
                ) { showSleepMenu() },
                MenuRow(R.drawable.ic_pip, getString(R.string.pip)) { enterPip() },
                MenuRow(R.drawable.ic_download, getString(R.string.menu_download)) { downloadCurrent() }
            )
        )
    }

    /** Save the current stream URL via system DownloadManager (⋮ → Download). */
    private fun downloadCurrent() {
        val ch = currentChannel()
        val url = ch?.url?.trim().orEmpty()
        if (url.isEmpty() || !url.startsWith("http")) {
            Toast.makeText(this, R.string.nothing_to_download, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val name = (ch?.name ?: "video")
                .replace(Regex("[\\/:*?\"<>|]"), "_")
                .take(60)
            val fileName = if (url.contains(".m3u8", true)) "$name.m3u8" else "$name.mp4"
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(ch?.name ?: "M3U Player")
                .setDescription(url)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
            req.addRequestHeader("User-Agent", Prefs.userAgent)
            try {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "M3UPlayer/$fileName")
            } catch (_: Exception) {
                // older / restricted devices — let DownloadManager pick a path
            }
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.download_failed) + ": ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showQualityMenu() {
        val current = Prefs.maxQuality
        showMenu(
            getString(R.string.quality),
            qualities.map { (h, label) ->
                MenuRow(R.drawable.ic_quality, if (h == 0) getString(R.string.quality_auto) else label, checked = h == current) {
                    setQuality(h)
                }
            },
            onBack = { showMoreMenu() }
        )
    }

    private fun showAspectMenu() {
        val names = arrayOf(getString(R.string.fit), getString(R.string.fill), getString(R.string.zoom))
        showMenu(
            getString(R.string.aspect_ratio),
            names.mapIndexed { i, n ->
                MenuRow(R.drawable.ic_aspect, n, checked = i == resizeIndex) {
                    resizeIndex = i
                    b.playerView.resizeMode = resizeModes[i]
                }
            },
            onBack = { showMoreMenu() }
        )
    }

    private fun showSleepMenu() {
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        showMenu(
            getString(R.string.sleep_timer),
            mins.map { m ->
                val label = if (m == 0) getString(R.string.sleep_off) else getString(R.string.sleep_minutes, m)
                MenuRow(R.drawable.ic_sleep, label, checked = m == sleepMin) {
                    sleepRunnable?.let { handler.removeCallbacks(it) }
                    sleepRunnable = null
                    sleepMin = m
                    if (m > 0) {
                        val r = Runnable { player?.pause(); sleepMin = 0 }
                        sleepRunnable = r
                        handler.postDelayed(r, m * 60_000L)
                        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onBack = { showMoreMenu() }
        )
    }

    /** Pick a resolution (360p ... 2K). Saved, so it also applies to the next channels. */
    private fun setQuality(h: Int) {
        withPlayer { p ->
            val pb = p.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            if (h > 0) {
                var best: Pair<Tracks.Group, Int>? = null
                var bestH = 0
                p.currentTracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }.forEach { g ->
                    for (i in 0 until g.length) {
                        val f = g.getTrackFormat(i)
                        if (g.isTrackSupported(i) && f.height in 1..h && f.height > bestH) {
                            best = g to i
                            bestH = f.height
                        }
                    }
                }
                best?.let { pb.setOverrideForType(TrackSelectionOverride(it.first.mediaTrackGroup, it.second)) }
            }
            p.trackSelectionParameters = pb.build()
        }
        Prefs.sp.edit().putString("max_quality", h.toString()).apply()
        val label = if (h == 0) getString(R.string.quality_auto) else qualities.first { it.first == h }.second
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
    }

    private fun selectTrack(type: Int, group: Tracks.Group?, index: Int, disable: Boolean = false) {
        val p = player ?: return
        val pb = p.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(type)
            .setTrackTypeDisabled(type, disable)
        if (group != null) pb.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, index))
        p.trackSelectionParameters = pb.build()
    }

    private fun showTrackMenu(type: Int, titleRes: Int) {
        val p = player
        if (p == null || p.mediaItemCount == 0) {
            Toast.makeText(this, R.string.nothing_playing, Toast.LENGTH_SHORT).show()
            return
        }
        val icon = R.drawable.ic_audio
        val groups = p.currentTracks.groups.filter { it.type == type }
        val rows = ArrayList<MenuRow>()

        val hasOverride = p.trackSelectionParameters.overrides.values.any { it.type == type }
        val disabled = p.trackSelectionParameters.disabledTrackTypes.contains(type)

        rows += MenuRow(icon, getString(R.string.track_default), checked = !hasOverride && !disabled) {
            selectTrack(type, null, 0)
        }
        var n = 0
        groups.forEach { g ->
            for (i in 0 until g.length) {
                n++
                val f = g.getTrackFormat(i)
                val ok = g.isTrackSupported(i)
                val sel = g.isTrackSelected(i) && (hasOverride || type == C.TRACK_TYPE_AUDIO) && !disabled
                rows += MenuRow(icon, describe(f, n) + (if (ok) "" else "  ✗"), checked = sel) {
                    if (ok) selectTrack(type, g, i)
                    else Toast.makeText(this, R.string.track_unsupported, Toast.LENGTH_LONG).show()
                }
            }
        }
        showMenu(getString(titleRes), rows, onBack = { showMoreMenu() })
    }

    private fun describe(f: Format, n: Int): String {
        val parts = ArrayList<String>()
        val lang = f.language?.takeIf { it != "und" }?.let { Locale(it).displayLanguage }
        parts += f.label ?: lang ?: "Track $n"
        f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)?.let { parts += it }
        if (f.channelCount > 0) parts += "${f.channelCount}ch"
        return parts.joinToString(" · ")
    }

    /** Modern dropdown card with icons, anchored under the ⋮ button. */
    private fun showMenu(title: String?, rows: List<MenuRow>, onBack: (() -> Unit)? = null) {
        menuPopup?.let { it.setOnDismissListener(null); it.dismiss() }
        val content = layoutInflater.inflate(R.layout.popup_menu, null)
        val header = content.findViewById<View>(R.id.menuHeader)
        val list = content.findViewById<LinearLayout>(R.id.menuList)

        if (title != null) {
            header.visibility = View.VISIBLE
            content.findViewById<TextView>(R.id.menuTitle).text = title
        }

        val popup = PopupWindow(content, dp(272), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.isOutsideTouchable = true
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(14).toFloat()

        if (title != null) {
            val back = View.OnClickListener {
                popup.dismiss()
                onBack?.invoke()
            }
            header.setOnClickListener(back)
            content.findViewById<View>(R.id.menuBack).setOnClickListener(back)
        }

        rows.forEach { r ->
            val row = layoutInflater.inflate(R.layout.item_menu_row, list, false)
            row.findViewById<ImageView>(R.id.rowIcon).setImageResource(r.icon)
            row.findViewById<TextView>(R.id.rowLabel).text = r.label
            row.findViewById<TextView>(R.id.rowValue).apply {
                if (r.value != null) { text = r.value; visibility = View.VISIBLE }
            }
            row.findViewById<View>(R.id.rowCheck).visibility = if (r.checked) View.VISIBLE else View.GONE
            row.findViewById<View>(R.id.rowArrow).visibility = if (r.arrow) View.VISIBLE else View.GONE
            row.setOnClickListener {
                popup.dismiss()
                r.onClick()
            }
            list.addView(row)
        }

        // keep the player controls (and the ⋮ button) on screen while the menu is open
        b.playerView.controllerShowTimeoutMs = 0
        b.playerView.showController()
        b.overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlayRunnable)
        popup.setOnDismissListener {
            menuPopup = null
            applyControlsTimeout()
            scheduleHideOverlay()
        }

        // very small screens (landscape): limit the height and let the list scroll
        content.measure(
            View.MeasureSpec.makeMeasureSpec(dp(272), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val anchor: View = if (b.btnMore.visibility == View.VISIBLE) b.btnMore else b.playerContainer
        val maxH = popup.getMaxAvailableHeight(anchor) - dp(8)
        if (maxH > 0 && content.measuredHeight > maxH) popup.height = maxH

        menuPopup = popup
        popup.showAsDropDown(anchor, 0, dp(6), Gravity.END)
    }

    // ---------- add playlist (+ button) ----------

    /** Bottom sheet: upload a file, add an m3u8 link, or refresh. Used by Playlists and Settings. */
    fun showAddSheet() {
        val d = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_add, null)
        d.setContentView(v)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
                ?.setBackgroundColor(Color.TRANSPARENT)
            d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        v.findViewById<View>(R.id.optFile).setOnClickListener {
            d.dismiss()
            filePicker.launch(arrayOf("*/*"))
        }
        v.findViewById<View>(R.id.optUrl).setOnClickListener {
            d.dismiss()
            askUrl()
        }
        v.findViewById<View>(R.id.optRefresh).setOnClickListener {
            d.dismiss()
            Store.refresh()
        }
        d.show()
    }

    private fun askUrl() {
        val v = layoutInflater.inflate(R.layout.dialog_add_url, null)
        val name = v.findViewById<EditText>(R.id.inputName)
        val url = v.findViewById<EditText>(R.id.inputUrl)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_url)
            .setView(v)
            .setPositiveButton(R.string.load) { _, _ ->
                val u = url.text.toString().trim()
                if (u.isNotEmpty()) Store.addUrl(name.text.toString().trim(), u)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
