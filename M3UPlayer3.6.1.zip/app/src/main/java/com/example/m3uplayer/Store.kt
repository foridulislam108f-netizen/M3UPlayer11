package com.example.m3uplayer

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** App-wide data: playlists, channels, favorites, history. Lives as long as the process. */
object Store {
    const val GROUP_ALL = "__all__"
    /** Special activeId: merge every saved playlist into one channel list. */
    const val ALL_PLAYLISTS_ID = "__all_playlists__"

    private lateinit var app: Application
    private lateinit var data: SharedPreferences
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val playlists = MutableStateFlow<List<PlaylistInfo>>(emptyList())
    val activeId = MutableStateFlow<String?>(null)
    val channels = MutableStateFlow<List<Channel>>(emptyList())
    val favorites = MutableStateFlow<Set<String>>(emptySet())
    val history = MutableStateFlow<List<Channel>>(emptyList())
    val groupFilter = MutableStateFlow(GROUP_ALL)
    val liveGroup = MutableStateFlow(GROUP_ALL)

    /** Live TV: links that answered (urls), progress of the check (done, total). */
    val working = MutableStateFlow<Set<String>>(emptySet())
    val checking = MutableStateFlow(false)
    val checkProgress = MutableStateFlow(0 to 0)
    val liveStamp = MutableStateFlow(0)
    private var checkJob: Job? = null
    private const val LIVE_TTL = 6L * 60 * 60 * 1000
    val loading = MutableStateFlow(false)
    val playingUrl = MutableStateFlow<String?>(null)
    val status = MutableStateFlow("")
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    val activeName: String
        get() = when (activeId.value) {
            ALL_PLAYLISTS_ID -> app.getString(R.string.all_playlists)
            else -> playlists.value.firstOrNull { it.id == activeId.value }?.name ?: ""
        }

    fun init(ctx: Application) {
        app = ctx
        data = ctx.getSharedPreferences("m3u_data", Context.MODE_PRIVATE)
        favorites.value = data.getStringSet("favs", emptySet())?.toSet() ?: emptySet()
        history.value = readHistory()
        playlists.value = readPlaylists()
        // migrate: old versions stored one "source" in prefs "m3u" (ignored on purpose)
        var id = data.getString("active", null)
        val valid = id == ALL_PLAYLISTS_ID || (id != null && playlists.value.any { it.id == id })
        if (!valid) id = playlists.value.firstOrNull()?.id
        activeId.value = id
        val first = id
        if (first != null) {
            scope.launch {
                withContext(Dispatchers.IO) { loadFromCache(first) }
                if (Prefs.autoRefresh) refresh(silent = true)
            }
        }
    }

    // ---------- playlists ----------

    private fun playlistFile(id: String) = File(app.filesDir, "playlist_$id.m3u")

    private fun readPlaylists(): List<PlaylistInfo> {
        val out = ArrayList<PlaylistInfo>()
        try {
            val arr = JSONArray(data.getString("playlists", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                var n = o.optInt("count", 0)
                if (n == 0) {
                    val f = playlistFile(id)
                    if (f.exists()) n = try { M3uParser.parse(f.readText()).size } catch (_: Exception) { 0 }
                }
                out += PlaylistInfo(id, o.getString("name"), o.optString("source"), o.optBoolean("url"), n, o.optLong("updatedAt", 0L))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun savePlaylists() {
        val arr = JSONArray()
        playlists.value.forEach {
            arr.put(JSONObject()
                .put("id", it.id).put("name", it.name).put("source", it.source)
                .put("url", it.isUrl).put("count", it.count).put("updatedAt", it.updatedAt))
        }
        data.edit().putString("playlists", arr.toString()).putString("active", activeId.value).apply()
    }

    private fun loadFromCache(id: String) {
        channels.value = if (id == ALL_PLAYLISTS_ID) mergeAllPlaylists()
        else {
            val f = playlistFile(id)
            if (f.exists()) M3uParser.parse(f.readText()) else emptyList()
        }
        groupFilter.value = GROUP_ALL
        liveGroup.value = GROUP_ALL
        resetLive()
    }

    /** Merge every playlist; group becomes "PlaylistName / original group". */
    private fun mergeAllPlaylists(): List<Channel> {
        val playlistsSnap = playlists.value
        val out = ArrayList<Channel>(playlistsSnap.sumOf { it.count.coerceAtLeast(0) })
        for (p in playlistsSnap) {
            val f = playlistFile(p.id)
            if (!f.exists()) continue
            val list = try {
                M3uParser.parse(f.readText())
            } catch (_: Exception) {
                emptyList()
            }
            for (c in list) {
                val g = if (c.group.isBlank()) p.name else "${p.name} · ${c.group}"
                out += c.copy(group = g)
            }
        }
        return out
    }

    /** Show channels from every playlist at once. */
    fun activateAll() {
        if (playlists.value.isEmpty()) return
        activeId.value = ALL_PLAYLISTS_ID
        savePlaylists()
        scope.launch {
            loading.value = true
            try {
                withContext(Dispatchers.IO) { loadFromCache(ALL_PLAYLISTS_ID) }
                messages.tryEmit(app.getString(R.string.msg_loaded, channels.value.size))
            } finally {
                loading.value = false
            }
        }
    }

    private fun download(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", Prefs.userAgent)
        c.setRequestProperty("Accept-Encoding", "gzip, identity")
        c.setRequestProperty("Connection", "close")
        val stream = try {
            if ("gzip".equals(c.contentEncoding, ignoreCase = true))
                java.util.zip.GZIPInputStream(c.inputStream)
            else c.inputStream
        } catch (_: Exception) {
            c.inputStream
        }
        return stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    fun addUrl(name: String, url: String) {
        scope.launch {
            loading.value = true
            try {
                val text = withContext(Dispatchers.IO) { download(url) }
                addFromText(name.ifBlank { guessName(url) }, url, true, text)
            } catch (e: Exception) {
                messages.tryEmit(app.getString(R.string.msg_load_failed, e.message ?: "?"))
            } finally {
                loading.value = false
            }
        }
    }

    fun addFile(uri: Uri) {
        scope.launch {
            loading.value = true
            try {
                val (name, text) = withContext(Dispatchers.IO) {
                    var n = "Playlist"
                    app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0 && c.moveToFirst()) n = c.getString(i).substringBeforeLast('.')
                    }
                    n to app.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                }
                addFromText(name, "", false, text)
            } catch (e: Exception) {
                messages.tryEmit(app.getString(R.string.msg_load_failed, e.message ?: "?"))
            } finally {
                loading.value = false
            }
        }
    }

    private fun addFromText(name: String, source: String, isUrl: Boolean, text: String) {
        val list = M3uParser.parse(text)
        if (list.isEmpty()) {
            messages.tryEmit(app.getString(R.string.msg_no_channels))
            return
        }
        var n = System.currentTimeMillis()
        while (playlists.value.any { it.id == n.toString() }) n++
        val id = n.toString()
        playlistFile(id).writeText(text)
        playlists.value = playlists.value + PlaylistInfo(id, name, source, isUrl, list.size, System.currentTimeMillis())
        activeId.value = id
        savePlaylists()
        channels.value = list
        groupFilter.value = GROUP_ALL
        liveGroup.value = GROUP_ALL
        resetLive()
        messages.tryEmit(app.getString(R.string.msg_loaded, list.size))
    }

    fun activate(id: String) {
        if (activeId.value == id) return
        activeId.value = id
        savePlaylists()
        scope.launch {
            loading.value = true
            try {
                withContext(Dispatchers.IO) { loadFromCache(id) }
            } finally {
                loading.value = false
            }
        }
    }

    fun remove(id: String) {
        playlistFile(id).delete()
        data.edit().remove("live_$id").remove("live_t_$id").remove("live_n_$id").apply()
        playlists.value = playlists.value.filterNot { it.id == id }
        if (activeId.value == id) {
            val next = playlists.value.firstOrNull()?.id
            activeId.value = next
            if (next != null) loadFromCache(next) else channels.value = emptyList()
        }
        savePlaylists()
    }

    fun refresh(silent: Boolean = false) {
        if (activeId.value == ALL_PLAYLISTS_ID) {
            // Refresh every URL playlist, then re-merge.
            scope.launch {
                loading.value = true
                try {
                    for (p in playlists.value.filter { it.isUrl }) {
                        try {
                            val text = withContext(Dispatchers.IO) { download(p.source) }
                            val list = M3uParser.parse(text)
                            if (list.isNotEmpty()) {
                                playlistFile(p.id).writeText(text)
                                playlists.value = playlists.value.map {
                                    if (it.id == p.id) it.copy(count = list.size, updatedAt = System.currentTimeMillis()) else it
                                }
                                data.edit().remove("live_${p.id}").apply()
                            }
                        } catch (_: Exception) { }
                    }
                    savePlaylists()
                    loadFromCache(ALL_PLAYLISTS_ID)
                    if (!silent) messages.tryEmit(app.getString(R.string.msg_loaded, channels.value.size))
                } finally {
                    loading.value = false
                }
            }
            return
        }
        val p = playlists.value.firstOrNull { it.id == activeId.value } ?: return
        if (!p.isUrl) {
            if (!silent) messages.tryEmit(app.getString(R.string.msg_file_no_refresh))
            return
        }
        scope.launch {
            loading.value = true
            try {
                val text = withContext(Dispatchers.IO) { download(p.source) }
                val list = M3uParser.parse(text)
                if (list.isEmpty()) {
                    if (!silent) messages.tryEmit(app.getString(R.string.msg_no_channels))
                } else {
                    playlistFile(p.id).writeText(text)
                    channels.value = list
                    playlists.value = playlists.value.map { if (it.id == p.id) it.copy(count = list.size, updatedAt = System.currentTimeMillis()) else it }
                    savePlaylists()
                    data.edit().remove("live_${p.id}").apply()
                    resetLive()
                    if (!silent) messages.tryEmit(app.getString(R.string.msg_loaded, list.size))
                }
            } catch (e: Exception) {
                if (!silent) messages.tryEmit(app.getString(R.string.msg_load_failed, e.message ?: "?"))
            } finally {
                loading.value = false
            }
        }
    }

    /** Rename a playlist (and change the link of a link playlist). */
    fun edit(id: String, name: String, url: String?) {
        val old = playlists.value.firstOrNull { it.id == id } ?: return
        val newUrl = if (old.isUrl && !url.isNullOrBlank()) url.trim() else old.source
        playlists.value = playlists.value.map {
            if (it.id == id) it.copy(name = name.ifBlank { old.name }, source = newUrl) else it
        }
        savePlaylists()
        if (old.isUrl && newUrl != old.source) {
            activate(id)
            refresh()
        }
    }

    // ---------- Live TV: keep only the links that work ----------

    private fun resetLive() {
        checkJob?.cancel()
        checkJob = null
        checking.value = false
        checkProgress.value = 0 to 0
        working.value = emptySet()
        liveStamp.value = liveStamp.value + 1
    }

    /** Tests every channel link of the active playlist (16 at a time) and remembers the result for 6 hours. */
    fun checkLive(force: Boolean = false) {
        val pid = activeId.value ?: return
        val list = channels.value
        if (list.isEmpty()) return
        if (!force) {
            if (checking.value) return
            // Combined view has no stable live cache key size across playlist edits.
            if (pid != ALL_PLAYLISTS_ID) {
                val cached = data.getStringSet("live_$pid", null)
                val t = data.getLong("live_t_$pid", 0L)
                val n = data.getInt("live_n_$pid", -1)
                if (cached != null && n == list.size && System.currentTimeMillis() - t < LIVE_TTL) {
                    if (working.value.isEmpty()) working.value = cached.toSet()
                    return
                }
            }
            if (working.value.isNotEmpty()) return
        }
        checkJob?.cancel()
        val job = scope.launch {
            checking.value = true
            working.value = emptySet()
            val urls = list.map { it.url }.distinct()
            checkProgress.value = 0 to urls.size
            val ok = LinkedHashSet<String>()
            var done = 0
            val gate = Semaphore(16)
            try {
                coroutineScope {
                    urls.forEach { u ->
                        launch {
                            gate.withPermit {
                                val good = withContext(Dispatchers.IO) { probe(u) }
                                if (good) {
                                    ok += u
                                    working.value = HashSet(ok)
                                }
                                done++
                                checkProgress.value = done to urls.size
                            }
                        }
                    }
                }
                if (ok.isNotEmpty()) {
                    data.edit()
                        .putStringSet("live_$pid", HashSet(ok))
                        .putLong("live_t_$pid", System.currentTimeMillis())
                        .putInt("live_n_$pid", list.size)
                        .apply()
                }
            } finally {
                if (checkJob === coroutineContext[Job]) checking.value = false
            }
        }
        checkJob = job
    }

    private fun probe(url: String): Boolean {
        if (!url.startsWith("http", ignoreCase = true)) return false
        var c: HttpURLConnection? = null
        try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", Prefs.userAgent)
            val code = c.responseCode
            if (code !in 200..299) return false
            val type = (c.contentType ?: "").lowercase()
            val buf = ByteArray(2048)
            val n = c.inputStream.read(buf)
            if (n <= 0) return false
            val head = String(buf, 0, n, Charsets.ISO_8859_1)
            val isPlaylist = url.contains(".m3u8", ignoreCase = true) || type.contains("mpegurl")
            return if (isPlaylist) {
                head.contains("#EXTM3U")
            } else {
                !type.contains("text/html") && !head.trimStart().startsWith("<")
            }
        } catch (_: Exception) {
            return false
        } finally {
            try { c?.disconnect() } catch (_: Exception) { }
        }
    }

    private fun guessName(url: String): String =
        try {
            val u = URL(url)
            u.path.substringAfterLast('/').substringBeforeLast('.').ifBlank { u.host }
        } catch (_: Exception) { "Playlist" }

    // ---------- favorites ----------

    fun toggleFav(url: String) {
        val s = favorites.value.toMutableSet()
        if (!s.add(url)) s.remove(url)
        favorites.value = s
        data.edit().putStringSet("favs", HashSet(s)).apply()
    }

    fun clearFavorites() {
        favorites.value = emptySet()
        data.edit().putStringSet("favs", HashSet()).apply()
    }

    // ---------- history ----------

    private fun readHistory(): List<Channel> {
        val out = ArrayList<Channel>()
        try {
            val arr = JSONArray(data.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Channel(o.getString("n"), o.getString("u"), o.optString("l"), o.optString("g"))
            }
        } catch (_: Exception) { }
        return out
    }

    fun addHistory(c: Channel) {
        val list = (listOf(c) + history.value.filter { it.url != c.url }).take(50)
        history.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.name).put("u", it.url).put("l", it.logo).put("g", it.group)) }
        data.edit().putString("history", arr.toString()).putString("last_url", c.url).apply()
    }

    fun clearHistory() {
        history.value = emptyList()
        data.edit().putString("history", "[]").apply()
    }

    val lastUrl: String? get() = data.getString("last_url", null)
}
